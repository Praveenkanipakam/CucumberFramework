package StepDefinition;		

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.openqa.selenium.By;		
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		

public class Steps {				

    public static WebDriver driver;			
    		
    @Given("^Open the Chrome and launch the application$")					
    public void launchUrl() throws Throwable							
    {		
    System.setProperty("webdriver.chrome.driver", "libs/chromedriver.exe");
       driver= new ChromeDriver();					
       driver.manage().window().maximize();
       driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       driver.get("http://newtours.demoaut.com/");					
    }		

    @When("^Register with FirstName \"([^\"]*)\" UserName \"([^\"]*)\" and Password \"([^\"]*)\"$")			
    public void register(String firstname, String username,String password) throws Throwable 							
    {	
    	driver.findElement(By.xpath("//a[contains(text(),'REGISTER')]")).click();
       driver.findElement(By.name("firstName")).sendKeys(firstname);					
       driver.findElement(By.id("email")).sendKeys(username);
       driver.findElement(By.name("password")).sendKeys(password);
       driver.findElement(By.name("confirmPassword")).sendKeys(password);
       driver.findElement(By.name("register")).click();
       
    }	
    
    @Given("^I navigate to Flights Tab$")					
    public void flightsTab() throws Throwable							
    {		
    	
			driver.findElement(By.xpath("//a[contains(text(),'Flights')]")).click();
			
    }	

    @Given("^Select Trip \"([^\"]*)\"$")
    public void select_Trip(String trip) throws Throwable {
       
    	driver.findElement(By.xpath("//input[@name='tripType']")).click();
    }

    @Given("^Choose total passengers \"([^\"]*)\"$")
    public void choose_total_passengers(String passengers) throws Throwable {
    	Select oSelect = new Select(driver.findElement(By.name("passCount")));
    	oSelect.selectByValue(passengers);
       
    }

    @Then("^Select Departing location \"([^\"]*)\" Month \"([^\"]*)\" and Date \"([^\"]*)\"$")
    public void select_Departing_location_Month_and_Date(String dLoc, String dMonth, String dDate) throws Throwable {
    	Select selLoc = new Select(driver.findElement(By.name("fromPort")));
    	selLoc.selectByValue(dLoc);
    	Select selMon = new Select(driver.findElement(By.name("fromMonth")));
    	selMon.selectByVisibleText(dMonth);
    	Select selDate = new Select(driver.findElement(By.name("fromDay")));
    	selDate.selectByValue(dDate);
        
    }

    @Then("^Select Arriving location \"([^\"]*)\" Month \"([^\"]*)\" and Date \"([^\"]*)\"$")
    public void select_Arriving_location_Month_and_Date(String aLoc, String aMonth, String aDate) throws Throwable {
    	Select selLoc = new Select(driver.findElement(By.name("toPort")));
    	selLoc.selectByValue(aLoc);
    	Select selMon = new Select(driver.findElement(By.name("toMonth")));
    	selMon.selectByVisibleText(aMonth);
    	Select selDate = new Select(driver.findElement(By.name("toDay")));
    	selDate.selectByValue(aDate);
    }

    @Then("^Service Class \"([^\"]*)\" and Airline \"([^\"]*)\"$")
    public void service_Class_and_Airline(String serClass, String airline) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	driver.findElement(By.xpath("//input[@name='servClass' and @value='"+serClass+"']")).click();
    	Select selAirline = new Select(driver.findElement(By.xpath("//select[@name='airline']")));
    	selAirline.selectByVisibleText(airline);
    	 
        
    }

    @Then("^Select Flights and Airline \"([^\"]*)\"$")
    public void select_Flights(String airline) throws Throwable {
    	
    	driver.findElement(By.xpath("//input[@name='findFlights']")).click();
    	driver.findElement(By.xpath("(//input[contains(@value,'"+airline+"')])[1]")).click();
    	driver.findElement(By.xpath("(//input[contains(@value,'"+airline+"')])[2]")).click();
    	driver.findElement(By.xpath("//input[@name='reserveFlights']")).click();
    		
        
    }

    @Then("^Enter Passengers Details like FirstName \"([^\"]*)\" LastName \"([^\"]*)\" and Numbers \"([^\"]*)\"$")
    public void enter_Passengers_Details_like_FirstName_LastName_and_Numbers(String firstName, String lastName, String number) throws Throwable {
       
    	driver.findElement(By.name("passFirst0")).sendKeys(firstName);					
        driver.findElement(By.name("passLast0")).sendKeys(lastName);
        driver.findElement(By.name("creditnumber")).sendKeys(number);
        driver.findElement(By.xpath("//input[@name='buyFlights']")).click();
    }

    @Then("^Verify Flight Confirmation$")
    public void verify_Flight_Confirmation() throws Throwable {
    	
    	driver.findElement(By.xpath("//*[contains(text(),'itinerary has been booked!')]")).isDisplayed();
       
    }
       
}		
